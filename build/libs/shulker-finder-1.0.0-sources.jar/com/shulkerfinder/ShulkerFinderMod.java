package com.shulkerfinder;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_1606;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ShulkerFinderMod implements ModInitializer {

    public static final String MOD_ID = "shulkerfinder";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("ShulkerFinder mod loaded!");

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            // /findshulker - finds nearest shulker to the command sender
            dispatcher.register(
                class_2170.method_9247("findshulker")
                    .requires(source -> source.method_9259(2))
                    .executes(ctx -> findShulker(ctx, null))
                    .then(class_2170.method_9244("player", class_2186.method_9305())
                        .executes(ctx -> {
                            try {
                                class_3222 target = class_2186.method_9315(ctx, "player");
                                return findShulker(ctx, target);
                            } catch (CommandSyntaxException e) {
                                ctx.getSource().method_9213(class_2561.method_43470("Player not found."));
                                return 0;
                            }
                        })
                    )
            );

            // /tpshulker - teleports the sender (or specified player) to nearest shulker
            dispatcher.register(
                class_2170.method_9247("tpshulker")
                    .requires(source -> source.method_9259(2))
                    .executes(ctx -> tpToShulker(ctx, null))
                    .then(class_2170.method_9244("player", class_2186.method_9305())
                        .executes(ctx -> {
                            try {
                                class_3222 target = class_2186.method_9315(ctx, "player");
                                return tpToShulker(ctx, target);
                            } catch (CommandSyntaxException e) {
                                ctx.getSource().method_9213(class_2561.method_43470("Player not found."));
                                return 0;
                            }
                        })
                    )
            );

            // /listshulkers - lists all shulkers in current dimension with coords
            dispatcher.register(
                class_2170.method_9247("listshulkers")
                    .requires(source -> source.method_9259(2))
                    .executes(ShulkerFinderMod::listShulkers)
            );
        });
    }

    private static List<class_1606> getShulkersInWorld(class_3218 world) {
        // Search in a very large box covering the whole world height and a wide range
        class_238 searchBox = new class_238(-30000000, world.method_31607(), -30000000,
                                 30000000, world.method_31600(), 30000000);
        return world.method_8390(class_1606.class, searchBox, e -> true);
    }

    private static int findShulker(CommandContext<class_2168> ctx, class_3222 targetPlayer) {
        class_2168 source = ctx.getSource();

        class_3222 player;
        try {
            player = targetPlayer != null ? targetPlayer : source.method_9207();
        } catch (CommandSyntaxException e) {
            source.method_9213(class_2561.method_43470("Must be a player or specify one with /findshulker <player>"));
            return 0;
        }

        class_3218 world = player.method_51469();
        List<class_1606> shulkers = getShulkersInWorld(world);

        if (shulkers.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("§eNo shulkers found in " + getDimName(world) + "."), false);
            return 0;
        }

        class_2338 playerPos = player.method_24515();
        class_1606 nearest = shulkers.stream()
            .min(Comparator.comparingDouble(s -> s.method_24515().method_10262(playerPos)))
            .orElse(null);

        if (nearest == null) return 0;

        class_2338 pos = nearest.method_24515();
        double dist = Math.sqrt(nearest.method_24515().method_10262(playerPos));

        source.method_9226(() -> class_2561.method_43470(
            String.format("§aNearest shulker to §e%s§a: §bX:%d Y:%d Z:%d §7(%.1f blocks away) §6[%s]",
                player.method_5477().getString(), pos.method_10263(), pos.method_10264(), pos.method_10260(),
                dist, getDimName(world))
        ), false);

        if (shulkers.size() > 1) {
            source.method_9226(() -> class_2561.method_43470(
                String.format("§7(Found %d shulker(s) total in this dimension — use §f/listshulkers§7 to see all)", shulkers.size())
            ), false);
        }

        return 1;
    }

    private static int tpToShulker(CommandContext<class_2168> ctx, class_3222 targetPlayer) {
        class_2168 source = ctx.getSource();

        class_3222 player;
        try {
            player = targetPlayer != null ? targetPlayer : source.method_9207();
        } catch (CommandSyntaxException e) {
            source.method_9213(class_2561.method_43470("Must be a player or specify one with /tpshulker <player>"));
            return 0;
        }

        class_3218 world = player.method_51469();
        List<class_1606> shulkers = getShulkersInWorld(world);

        if (shulkers.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("§eNo shulkers found in " + getDimName(world) + "."), false);
            return 0;
        }

        class_2338 playerPos = player.method_24515();
        class_1606 nearest = shulkers.stream()
            .min(Comparator.comparingDouble(s -> s.method_24515().method_10262(playerPos)))
            .orElse(null);

        if (nearest == null) return 0;

        class_2338 pos = nearest.method_24515();

        // Teleport player 1 block above the shulker so they don't land inside it
        player.method_14251(world, pos.method_10263() + 0.5, pos.method_10264() + 1.0, pos.method_10260() + 0.5,
                        player.method_36454(), player.method_36455());

        source.method_9226(() -> class_2561.method_43470(
            String.format("§aTeleported §e%s §ato shulker at §bX:%d Y:%d Z:%d §6[%s]",
                player.method_5477().getString(), pos.method_10263(), pos.method_10264(), pos.method_10260(), getDimName(world))
        ), false);

        return 1;
    }

    private static int listShulkers(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        final class_3218 world = (source.method_9225() instanceof class_3218 sw) ? sw : null;

        if (world == null) {
            source.method_9213(class_2561.method_43470("Could not determine world."));
            return 0;
        }

        List<class_1606> shulkers = getShulkersInWorld(world);

        if (shulkers.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("§eNo shulkers found in " + getDimName(world) + "."), false);
            return 0;
        }

        source.method_9226(() -> class_2561.method_43470(
            String.format("§a--- Shulkers in §6%s §a(%d found) ---", getDimName(world), shulkers.size())
        ), false);

        for (int i = 0; i < shulkers.size(); i++) {
            class_1606 s = shulkers.get(i);
            class_2338 pos = s.method_24515();
            int idx = i + 1;
            source.method_9226(() -> class_2561.method_43470(
                String.format("§7#%d §bX:%d Y:%d Z:%d", idx, pos.method_10263(), pos.method_10264(), pos.method_10260())
            ), false);
        }

        return 1;
    }

    private static String getDimName(class_3218 world) {
        String key = world.method_27983().method_29177().method_12832();
        return switch (key) {
            case "the_end"    -> "The End";
            case "the_nether" -> "The Nether";
            default           -> "Overworld";
        };
    }
}
